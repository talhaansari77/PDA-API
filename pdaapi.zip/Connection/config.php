<?php 
// define("hostName", "localhost");
// define("user", "root");
// define("password", "");
// define("dbName", "pda");

$conn = mysqli_connect("localhost", "root", "", "pda");
// $conn = mysqli_connect($hostName, $user, $password, $dbName);

?>